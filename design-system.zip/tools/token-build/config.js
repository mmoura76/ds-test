const StyleDictionary = require('style-dictionary');

module.exports = {
  source: ['libs/tokens/src/**/*.json'],
  platforms: {
    css: {
      transformGroup: 'css',
      buildPath: 'libs/tokens/dist/',
      files: [
        {
          destination: 'tokens.css',
          format: 'css/variables'
        }
      ]
    }
  }
};